w# Gerenciador de Atividades

Aplicação completa para gerenciamento de atividades desenvolvida com React no frontend e FastAPI no backend.

## Funcionalidades

- ✅ Adicionar novas atividades com título e descrição
- ✏️ Editar atividades existentes
- 🗑️ Excluir atividades
- 🔄 Atualizar status das atividades (pendente, em andamento, concluído)
- 📊 Visualização agrupada por status
- 💾 Persistência de dados em arquivo JSON
- 🎨 Interface responsiva e intuitiva com Tailwind CSS

## Tecnologias Utilizadas

### Backend
- Python 3.8+
- FastAPI
- Pydantic
- Uvicorn

### Frontend
- React 18
- Vite
- Tailwind CSS
- JavaScript (ES6+)

## Estrutura do Projeto

```
.
├── backend/
│   ├── main.py           # API FastAPI com endpoints
│   ├── models.py         # Modelos Pydantic
│   ├── database.py       # Funções de persistência
│   ├── requirements.txt  # Dependências Python
│   └── activities.json   # Banco de dados (criado automaticamente)
│
└── frontend/
    ├── src/
    │   ├── components/
    │   │   ├── ActivityForm.jsx  # Formulário de atividades
    │   │   ├── ActivityList.jsx  # Lista agrupada
    │   │   └── ActivityCard.jsx  # Card individual
    │   ├── App.jsx              # Componente principal
    │   ├── main.jsx             # Entry point
    │   └── index.css            # Estilos globais
    ├── package.json
    └── tailwind.config.js
```

## Como Executar

### Pré-requisitos

- Python 3.8 ou superior
- Node.js 16 ou superior
- npm ou yarn

### Backend

1. Navegue até a pasta do backend:
```bash
cd backend
```

2. Instale as dependências:
```bash
pip install -r requirements.txt
```

3. Execute o servidor:
```bash
python main.py
```

O backend estará rodando em `http://localhost:8000`

Para ver a documentação interativa da API, acesse: `http://localhost:8000/docs`

### Frontend

1. Em outro terminal, navegue até a pasta do frontend:
```bash
cd frontend
```

2. Instale as dependências:
```bash
npm install
npm install -D @tailwindcss/postcss
```

3. Execute o servidor de desenvolvimento:
```bash
npm run dev
```

O frontend estará rodando em `http://localhost:5173`

## Endpoints da API

- `GET /activities` - Lista todas as atividades
- `GET /activities/{id}` - Busca uma atividade específica
- `POST /activities` - Cria uma nova atividade
- `PUT /activities/{id}` - Atualiza uma atividade
- `DELETE /activities/{id}` - Exclui uma atividade

## Uso da Aplicação

1. Acesse `http://localhost:5173` no navegador
2. Preencha o formulário com título, descrição e status
3. Clique em "Adicionar" para criar uma nova atividade
4. As atividades serão exibidas em colunas separadas por status
5. Use os ícones de editar (✏️) e excluir (🗑️) em cada card
6. Altere o status diretamente pelo dropdown no card

## Observações

- O backend deve estar rodando para que o frontend funcione corretamente
- Os dados são salvos automaticamente no arquivo `activities.json`
- A aplicação possui tratamento de erros e feedback visual
- Interface totalmente responsiva para mobile e desktop

## Desenvolvido por

Projeto desenvolvido como teste técnico de React + Python.
