import { useState, useEffect } from 'react';
import ActivityForm from './components/ActivityForm';
import ActivityList from './components/ActivityList';
import './index.css';

const API_URL = 'http://localhost:8000';

function App() {
  const [activities, setActivities] = useState([]);
  const [editingActivity, setEditingActivity] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchActivities();
  }, []);

  const fetchActivities = async () => {
    try {
      setLoading(true);
      const response = await fetch(`${API_URL}/activities`);
      if (!response.ok) throw new Error('Erro ao carregar atividades');
      const data = await response.json();
      setActivities(data);
      setError(null);
    } catch (err) {
      setError('Não foi possível conectar ao servidor. Verifique se o backend está rodando.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (formData) => {
    try {
      if (editingActivity) {
        const response = await fetch(`${API_URL}/activities/${editingActivity.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(formData)
        });
        if (!response.ok) throw new Error('Erro ao atualizar atividade');
        setEditingActivity(null);
      } else {
        const response = await fetch(`${API_URL}/activities`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(formData)
        });
        if (!response.ok) throw new Error('Erro ao criar atividade');
      }
      fetchActivities();
    } catch (err) {
      alert('Erro ao salvar atividade: ' + err.message);
    }
  };

  const handleEdit = (activity) => {
    setEditingActivity(activity);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = async (id) => {
    if (!confirm('Tem certeza que deseja excluir esta atividade?')) return;

    try {
      const response = await fetch(`${API_URL}/activities/${id}`, {
        method: 'DELETE'
      });
      if (!response.ok) throw new Error('Erro ao excluir atividade');
      fetchActivities();
    } catch (err) {
      alert('Erro ao excluir atividade: ' + err.message);
    }
  };

  const handleUpdateStatus = async (id, newStatus) => {
    try {
      const response = await fetch(`${API_URL}/activities/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus })
      });
      if (!response.ok) throw new Error('Erro ao atualizar status');
      fetchActivities();
    } catch (err) {
      alert('Erro ao atualizar status: ' + err.message);
    }
  };

  const handleCancel = () => {
    setEditingActivity(null);
  };

  const stats = {
    total: activities.length,
    pendente: activities.filter(a => a.status === 'pendente').length,
    emAndamento: activities.filter(a => a.status === 'em andamento').length,
    concluido: activities.filter(a => a.status === 'concluído').length
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-600 via-purple-600 to-indigo-700">
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmZmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDE2YzAtMS4xLS45LTItMi0yaC04Yy0xLjEgMC0yIC45LTIgMnY4YzAgMS4xLjkgMiAyIDJoOGMxLjEgMCAyLS45IDItMnYtOHoiLz48L2c+PC9nPjwvc3ZnPg==')] opacity-30"></div>

      <div className="relative container mx-auto px-4 py-8 max-w-7xl">
        <header className="text-center mb-10 animate-fade-in">
          <div className="inline-block mb-4 p-4 bg-white/10 backdrop-blur-lg rounded-2xl">
            <h1 className="text-5xl font-extrabold text-white mb-3 drop-shadow-lg">
              📋 Gerenciador de Atividades
            </h1>
            <p className="text-white/90 text-lg font-medium">Organize suas tarefas de forma eficiente e produtiva</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8 max-w-4xl mx-auto">
            <div className="bg-white/10 backdrop-blur-md rounded-xl p-4 border border-white/20 hover:bg-white/20 transition-all duration-300 hover:scale-105">
              <div className="text-3xl font-bold text-white">{stats.total}</div>
              <div className="text-white/80 text-sm font-medium mt-1">Total</div>
            </div>
            <div className="bg-amber-500/20 backdrop-blur-md rounded-xl p-4 border border-amber-300/30 hover:bg-amber-500/30 transition-all duration-300 hover:scale-105">
              <div className="text-3xl font-bold text-white">{stats.pendente}</div>
              <div className="text-white/80 text-sm font-medium mt-1">Pendentes</div>
            </div>
            <div className="bg-blue-500/20 backdrop-blur-md rounded-xl p-4 border border-blue-300/30 hover:bg-blue-500/30 transition-all duration-300 hover:scale-105">
              <div className="text-3xl font-bold text-white">{stats.emAndamento}</div>
              <div className="text-white/80 text-sm font-medium mt-1">Em Andamento</div>
            </div>
            <div className="bg-green-500/20 backdrop-blur-md rounded-xl p-4 border border-green-300/30 hover:bg-green-500/30 transition-all duration-300 hover:scale-105">
              <div className="text-3xl font-bold text-white">{stats.concluido}</div>
              <div className="text-white/80 text-sm font-medium mt-1">Concluídas</div>
            </div>
          </div>
        </header>

        {error && (
          <div className="bg-red-500/90 backdrop-blur-md border border-red-300/50 text-white px-6 py-4 rounded-xl mb-6 shadow-xl animate-shake">
            <div className="flex items-center gap-3">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <span className="font-medium">{error}</span>
            </div>
          </div>
        )}

        <ActivityForm
          onSubmit={handleSubmit}
          editingActivity={editingActivity}
          onCancel={handleCancel}
        />

        {loading ? (
          <div className="text-center py-20">
            <div className="inline-block animate-spin rounded-full h-16 w-16 border-4 border-white/30 border-t-white"></div>
            <p className="mt-6 text-white text-lg font-medium">Carregando atividades...</p>
          </div>
        ) : (
          <ActivityList
            activities={activities}
            onEdit={handleEdit}
            onDelete={handleDelete}
            onUpdateStatus={handleUpdateStatus}
          />
        )}
      </div>
    </div>
  );
}

export default App;
