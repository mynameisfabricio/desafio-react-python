export default function ActivityCard({ activity, onEdit, onDelete, onUpdateStatus }) {
    const statusConfig = {
        'pendente': {
            bg: 'bg-gradient-to-br from-amber-50 to-yellow-50',
            border: 'border-amber-300',
            badge: 'bg-amber-500 text-white',
            icon: '⏳'
        },
        'em andamento': {
            bg: 'bg-gradient-to-br from-blue-50 to-cyan-50',
            border: 'border-blue-300',
            badge: 'bg-blue-500 text-white',
            icon: '🔄'
        },
        'concluído': {
            bg: 'bg-gradient-to-br from-green-50 to-emerald-50',
            border: 'border-green-300',
            badge: 'bg-green-500 text-white',
            icon: '✅'
        }
    };

    const config = statusConfig[activity.status];
    const statusOptions = ['pendente', 'em andamento', 'concluído'];

    return (
        <div className={`${config.bg} rounded-xl shadow-lg p-5 mb-4 border-2 ${config.border} hover:shadow-2xl transition-all duration-300 hover:scale-[1.02] group`}>
            <div className="flex justify-between items-start mb-3">
                <div className="flex-1">
                    <h3 className="text-xl font-bold text-gray-800 mb-1 group-hover:text-purple-700 transition-colors">{activity.titulo}</h3>
                    <span className={`inline-block px-3 py-1 rounded-full text-xs font-bold ${config.badge}`}>
                        {config.icon} {activity.status.toUpperCase()}
                    </span>
                </div>
                <div className="flex gap-2">
                    <button
                        onClick={() => onEdit(activity)}
                        className="p-2 bg-white rounded-lg text-blue-600 hover:bg-blue-600 hover:text-white transition-all duration-200 shadow-md hover:shadow-lg hover:scale-110"
                        title="Editar"
                    >
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                        </svg>
                    </button>
                    <button
                        onClick={() => onDelete(activity.id)}
                        className="p-2 bg-white rounded-lg text-red-600 hover:bg-red-600 hover:text-white transition-all duration-200 shadow-md hover:shadow-lg hover:scale-110"
                        title="Excluir"
                    >
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                    </button>
                </div>
            </div>

            <p className="text-gray-700 mb-4 leading-relaxed">{activity.descricao}</p>

            <div className="flex items-center gap-2 pt-3 border-t-2 border-gray-200">
                <span className="text-sm text-gray-600 font-semibold">Alterar status:</span>
                <select
                    value={activity.status}
                    onChange={(e) => onUpdateStatus(activity.id, e.target.value)}
                    className="flex-1 px-3 py-2 rounded-lg border-2 border-gray-300 font-medium cursor-pointer hover:border-purple-500 focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all bg-white"
                >
                    {statusOptions.map(status => (
                        <option key={status} value={status}>
                            {statusConfig[status].icon} {status.charAt(0).toUpperCase() + status.slice(1)}
                        </option>
                    ))}
                </select>
            </div>
        </div>
    );
}
