import { useState, useEffect } from 'react';

export default function ActivityForm({ onSubmit, editingActivity, onCancel }) {
    const [formData, setFormData] = useState({
        titulo: '',
        descricao: '',
        status: 'pendente'
    });

    useEffect(() => {
        if (editingActivity) {
            setFormData({
                titulo: editingActivity.titulo,
                descricao: editingActivity.descricao,
                status: editingActivity.status
            });
        }
    }, [editingActivity]);

    const handleSubmit = (e) => {
        e.preventDefault();
        onSubmit(formData);
        setFormData({ titulo: '', descricao: '', status: 'pendente' });
    };

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        });
    };

    return (
        <form onSubmit={handleSubmit} className="bg-white/95 backdrop-blur-xl rounded-2xl shadow-2xl p-8 mb-8 border border-white/20 hover:shadow-purple-500/20 transition-all duration-300">
            <div className="flex items-center gap-3 mb-6">
                <div className={`p-3 rounded-xl ${editingActivity ? 'bg-gradient-to-br from-amber-400 to-orange-500' : 'bg-gradient-to-br from-purple-500 to-indigo-600'}`}>
                    {editingActivity ? (
                        <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                        </svg>
                    ) : (
                        <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                        </svg>
                    )}
                </div>
                <h2 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-indigo-600 bg-clip-text text-transparent">
                    {editingActivity ? 'Editar Atividade' : 'Nova Atividade'}
                </h2>
            </div>

            <div className="mb-5">
                <label htmlFor="titulo" className="block text-gray-700 font-bold mb-2 text-sm uppercase tracking-wide">
                    Título
                </label>
                <input
                    type="text"
                    id="titulo"
                    name="titulo"
                    value={formData.titulo}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200 bg-gray-50 hover:bg-white"
                    placeholder="Digite o título da atividade"
                />
            </div>

            <div className="mb-5">
                <label htmlFor="descricao" className="block text-gray-700 font-bold mb-2 text-sm uppercase tracking-wide">
                    Descrição
                </label>
                <textarea
                    id="descricao"
                    name="descricao"
                    value={formData.descricao}
                    onChange={handleChange}
                    required
                    rows="4"
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200 bg-gray-50 hover:bg-white resize-none"
                    placeholder="Descreva a atividade em detalhes"
                />
            </div>

            <div className="mb-6">
                <label htmlFor="status" className="block text-gray-700 font-bold mb-2 text-sm uppercase tracking-wide">
                    Status
                </label>
                <select
                    id="status"
                    name="status"
                    value={formData.status}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200 bg-gray-50 hover:bg-white cursor-pointer"
                >
                    <option value="pendente">⏳ Pendente</option>
                    <option value="em andamento">🔄 Em Andamento</option>
                    <option value="concluído">✅ Concluído</option>
                </select>
            </div>

            <div className="flex gap-3">
                <button
                    type="submit"
                    className="flex-1 bg-gradient-to-r from-purple-600 to-indigo-600 text-white px-6 py-3 rounded-xl font-bold hover:from-purple-700 hover:to-indigo-700 transition-all duration-200 shadow-lg hover:shadow-xl hover:scale-[1.02] active:scale-[0.98]"
                >
                    {editingActivity ? '💾 Atualizar' : '➕ Adicionar'}
                </button>

                {editingActivity && (
                    <button
                        type="button"
                        onClick={onCancel}
                        className="px-6 py-3 border-2 border-gray-300 rounded-xl font-bold hover:bg-gray-100 transition-all duration-200 hover:scale-[1.02] active:scale-[0.98] text-gray-700"
                    >
                        ✖️ Cancelar
                    </button>
                )}
            </div>
        </form>
    );
}
