import ActivityCard from './ActivityCard';

export default function ActivityList({ activities, onEdit, onDelete, onUpdateStatus }) {
    const groupedActivities = {
        'pendente': activities.filter(a => a.status === 'pendente'),
        'em andamento': activities.filter(a => a.status === 'em andamento'),
        'concluído': activities.filter(a => a.status === 'concluído')
    };

    const statusConfig = {
        'pendente': {
            title: 'Pendentes',
            icon: '⏳',
            gradient: 'from-amber-400 to-orange-500'
        },
        'em andamento': {
            title: 'Em Andamento',
            icon: '🔄',
            gradient: 'from-blue-400 to-cyan-500'
        },
        'concluído': {
            title: 'Concluídas',
            icon: '✅',
            gradient: 'from-green-400 to-emerald-500'
        }
    };

    return (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {Object.entries(groupedActivities).map(([status, items]) => {
                const config = statusConfig[status];
                return (
                    <div key={status} className="bg-white/90 backdrop-blur-lg rounded-2xl p-6 shadow-xl border border-white/30 hover:shadow-2xl transition-all duration-300">
                        <div className={`flex items-center justify-between mb-6 pb-4 border-b-2 border-gradient-to-r ${config.gradient}`}>
                            <h2 className="text-2xl font-bold text-gray-800 flex items-center gap-3">
                                <span className={`text-3xl p-2 rounded-xl bg-gradient-to-br ${config.gradient} text-white shadow-lg`}>
                                    {config.icon}
                                </span>
                                {config.title}
                            </h2>
                            <span className={`bg-gradient-to-br ${config.gradient} text-white rounded-full w-10 h-10 flex items-center justify-center text-lg font-bold shadow-lg`}>
                                {items.length}
                            </span>
                        </div>

                        <div className="space-y-4 max-h-[600px] overflow-y-auto pr-2 custom-scrollbar">
                            {items.length === 0 ? (
                                <div className="text-center py-12">
                                    <div className="text-6xl mb-4 opacity-30">{config.icon}</div>
                                    <p className="text-gray-400 italic font-medium">Nenhuma atividade</p>
                                </div>
                            ) : (
                                items.map(activity => (
                                    <ActivityCard
                                        key={activity.id}
                                        activity={activity}
                                        onEdit={onEdit}
                                        onDelete={onDelete}
                                        onUpdateStatus={onUpdateStatus}
                                    />
                                ))
                            )}
                        </div>
                    </div>
                );
            })}
        </div>
    );
}
